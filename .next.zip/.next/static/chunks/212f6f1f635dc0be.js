__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/40c3e8fcea2dbf93.js",
  "static/chunks/turbopack-374122435c4f9204.js"
])
