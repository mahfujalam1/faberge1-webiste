__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/40c3e8fcea2dbf93.js",
  "static/chunks/turbopack-2c419e3fffaf1e85.js"
])
