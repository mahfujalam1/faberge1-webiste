globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/40c3e8fcea2dbf93.js",
      "static/chunks/turbopack-374122435c4f9204.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/40c3e8fcea2dbf93.js",
      "static/chunks/turbopack-2c419e3fffaf1e85.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0ed6969d19967240.js",
    "static/chunks/076e8f4380a721aa.js",
    "static/chunks/22aca8368e4c82b1.js",
    "static/chunks/1658771afb6338f6.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/32b4d63e10d31351.js",
    "static/chunks/turbopack-cb8b6ff7597e4b3c.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];